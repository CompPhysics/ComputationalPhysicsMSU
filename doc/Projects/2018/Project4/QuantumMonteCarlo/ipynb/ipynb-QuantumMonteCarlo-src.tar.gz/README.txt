This IPython notebook QuantumMonteCarlo.ipynb does not require any additional
programs.
