This IPython notebook pde.ipynb does not require any additional
programs.
