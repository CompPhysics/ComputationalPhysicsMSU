This IPython notebook linalg.ipynb does not require any additional
programs.
