This IPython notebook statphys.ipynb does not require any additional
programs.
