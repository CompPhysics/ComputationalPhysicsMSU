This IPython notebook codeoptimization.ipynb does not require any additional
programs.
