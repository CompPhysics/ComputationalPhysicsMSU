This IPython notebook mcint.ipynb does not require any additional
programs.
