This IPython notebook ode.ipynb does not require any additional
programs.
