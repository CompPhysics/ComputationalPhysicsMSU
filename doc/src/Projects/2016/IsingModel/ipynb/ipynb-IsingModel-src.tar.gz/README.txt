This IPython notebook IsingModel.ipynb does not require any additional
programs.
